Implementation of RAID structures 0, 1, 01, 4, and 5 on the xv6 operating system.
