#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void check_data(uint blocks, uchar *blk, uint block_size);

int
main(int argc, char *argv[])
{

//    init_raid(RAID5);
    init_raid(RAID1);


    uint disk_num, block_num, block_size;
    info_raid(&block_num, &block_size, &disk_num);
    printf("%d %d %d", disk_num, block_num, block_size);
    uint blocks = (512 > block_num ? block_num : 512);

    uchar* blk = malloc(block_size);
    for (uint i = 0; i < blocks; i++) {
        for (uint j = 0; j < block_size; j++) {
            blk[j] = j + i;
        }
        write_raid(i, blk);
    }
    check_data(blocks, blk, block_size);

	disk_fail_raid(2);
	disk_fail_raid(1);

    printf("\ndisk fail\n");

    check_data(blocks, blk, block_size);

    disk_repaired_raid(2);

    check_data(blocks, blk, block_size);

    free(blk);

    printf("Test finished succesfuly \n");
    exit(0);

}

void check_data(uint blocks, uchar *blk, uint block_size)
{
	//int cnt = 0;
    for (uint i = 0; i < blocks; i++)
    {
        read_raid(i, blk);
        for (uint j = 0; j < block_size; j++)
        {
			//printf("\n%d\n",blk[j]);
            if ((uchar)(j + i) != blk[j])
            {
				//cnt++;
                printf("expected=%d got=%d", j + i, blk[j]);
                printf("Data in the block %d faulty\n", i);
                break;
            }
        }
    }

	//printf("Num of failed blks: %d\n", cnt);
}